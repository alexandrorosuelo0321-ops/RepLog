# RepLog — compilazione APK usando solo il telefono

Non serve installare Android Studio sul telefono: la compilazione avviene su GitHub Actions, nel cloud.

## Metodo consigliato (browser del telefono)

1. Apri https://github.com e crea un account, se non ne hai già uno.
2. Crea un nuovo repository chiamato `RepLog` e impostalo come **Public** (GitHub Actions è normalmente più semplice da usare con un repository pubblico e non contiene segreti in questo progetto).
3. Per caricare il progetto, estrai `RepLogAndroid_Source.zip` con l'app File/Samsung Archivio. Dal browser GitHub, carica i file e le cartelle del progetto mantenendo la struttura. Assicurati che `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, la cartella `app` e la cartella `.github/workflows` siano nella radice del repository.
4. Dopo aver caricato i file, apri la scheda **Actions** del repository. Se richiesto, abilita GitHub Actions.
5. Seleziona **Build RepLog APK** e premi **Run workflow** (oppure attendi che parta dopo un push).
6. Attendi che l'esecuzione diventi verde. Aprila e vai alla sezione **Artifacts**.
7. Scarica `RepLog-debug-APK.zip` sul telefono ed estrailo: contiene `app-debug.apk`.
8. Tocca l'APK per installarlo. Android potrebbe chiederti di consentire l'installazione da quella sorgente; autorizzala solo se sei sicuro di aver scaricato il file dal tuo repository.

## Nota importante

Questo workflow prova a compilare il progetto nel cloud; non garantisce che il primo tentativo riesca. Se la compilazione fallisce, apri il log dell'esecuzione e condividilo qui: ti aiuterò a correggere l'errore. L'APK debug è per test personali, non è una release firmata per la distribuzione sul Play Store.
